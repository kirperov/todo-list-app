
Author: Kirill Petrov
Last update: 11/01/2022
Version: 0.1


# Documentation Todo list app


## Sommaire

 1. **Utilisation non technique**
 1.1 Introduction
 1.2 Ajout d'un todo
 1.3 Édition d'un todo
 1.4 Suppression d'un todo
 2. **Fonctionnement technique de l'application**
 3. **Audit**
---




 1. **Utilisation non technique**
 1.1 Introduction

 L'utilisation de l'application se fait de manière très simple et intuitif. Tout d'abord nous allons voir les fonctionnalités de l'application du côté utilisateur. Todo app list est une application one page.

 - *Arrivé sur la page de l'application*
 ![First](https://raw.githubusercontent.com/kirperov/todo-list-app/main/doc/images/Capture1.PNG)
- *Les option de filtre sur les todos*
1 Les todos restants à faire
2 Pour afficher tous les todos inclus les complétées
3 Les todos actives qui sont pas encore complétées

![Filters](https://raw.githubusercontent.com/kirperov/todo-list-app/3d139f5101496c5176e5141004fec08a1124db61/doc/images/Capture3.jpg)
